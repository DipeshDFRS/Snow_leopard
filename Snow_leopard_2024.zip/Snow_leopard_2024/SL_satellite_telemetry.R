
getwd()
sessionInfo()
setwd("C:/Desktop/Radio_collar")

# load packages####
library(tidyverse)
library(lubridate)
library(ggplot2)
library(dplyr)
library(plotly)
library(readxl)
library(rnaturalearth)
library(sf)
library(furrr)
library(future)
library(momentuHMM)
library(crawl)
library(tictoc)
library(move)
library(adehabitatHR)
library(raster)
library(caret)
library(Metrics)
library(e1071)
library(ExtractTrainData)
library(mitools)
library(doFuture)
library(HMMpa)

# Raster Data ####
#### raster images downloaded from Shuttle Radar Topography Mission (SRTM)
#### https://srtm.csi.cgiar.org/srtmdata/

r1 <- raster("C:/Users/user-1/Downloads/Radio_collar/N27E087.hgt")
r2 <- raster("C:/Users/user-1/Downloads/Radio_collar/N27E088.hgt")
r3 <- raster("C:/Users/user-1/Downloads/Radio_collar/N28E087.hgt")
r4 <- raster("C:/Users/user-1/Downloads/Radio_collar/N28E086.hgt")
r5 <- raster("C:/Users/user-1/Downloads/Radio_collar/N28E088.hgt")
r6 <- raster("C:/Users/user-1/Downloads/Radio_collar/N27E086.hgt")


dem <- merge(r1,r2,r3,r4,r5,r6)

plot(dem)

slope<-terrain(dem, opt= "slope", unit= "degrees", neighbors=8)

aspect <-terrain(dem, opt= "aspect",unit= "degrees", neighbors=8)

## Stack slope, aspect####
predictors <-stack(slope,aspect)

features <-read_excel(file.choose(),1) %>% 
  mutate(UID=paste0(x, y))
features
view(features)
names(features)
coordinates(features)<-~x + y
proj4string(features)<-CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0")
str(features)
Out.colName<-In.colName<-"id"
e <- ExtractByPoint(predictors,features,Out.colName,In.colName)
write.csv(e,"3slope_GPS_Collar_All_4SL.csv")


SL_slope <- read.csv("3slope_GPS_Collar_All_4SL.csv") %>% 
  rename(SN=X)

SL_raw <- read_excel(file.choose(),1)

SL_raw$SN <- seq(1, 4707)

SL <- left_join(SL_raw, SL_slope, by="SN")
       
write.csv(SL, "SL_slope_included.csv")
    


#Movement behaviour ####
SL <- read.csv("SL_slope_included.csv", as.is = TRUE )   
glimpse(SL)
summary(SL)
SL_merge_name <- SL[-c(1,19,22)] %>%
  rename(id=id.x) %>% 
  mutate(id = ifelse(id == "13646", "13647", id))%>%
  rename(Temp = Temp...C.) %>% 
  rename(Elevation= Height..m. )
glimpse(SL_merge_name)
view(SL_merge_name)
str(SL_merge_name)

##Data inspection####
table(SL_merge_name$id, useNA="ifany")
table(SL_merge_name$Type, useNA = "ifany")

SL_na<- SL_merge_name%>%
  filter(!is.na(id))
#view(SL_na) 


##Datetime####

SL_na$DateTime[1:10]
SL_time<- SL_na%>%
  mutate(DateTime= as_datetime(DateTime, format ='%Y-%m-%d %H:%M:%S'))


glimpse(SL_time)
summary(SL_time)
SL_time$DateTime[1:10]
class(SL_time$DateTime)

##Change id to character####

SL_time$id <- as.character(SL_na$id)

ggplot(data=SL_time, aes(x, y, color=id))+
  geom_path(aes(group=id), size=0.25)+
  scale_color_viridis_d()+
  theme_bw()



##Land layers####
#install.packages("rnaturalearthdata")
world <- rnaturalearth::ne_countries(scale=50, continent = "Asia", returnclass = "sf")
ggplot()+
  geom_sf(data=world) +
  geom_path(data=SL_time, aes(x, y, group=id, color=id), size= 0.25
  )+
  scale_color_viridis_d()+
  theme_bw()+
  coord_sf(xlim = c(min(SL_time$x)-1, max(SL_time$x)+1),
           ylim= c(min(SL_time$y)-1, max(SL_time$y)+1))

##Interactive map####
plotly::ggplotly(
  ggplot()+
    geom_sf(data=world) +
    geom_path(data=SL_time, aes(x, y, group=id, color=id), size= 0.25
    )+
    scale_color_viridis_d()+
    theme_bw()+
    coord_sf(xlim = c(min(SL_time$x)-1, max(SL_time$x)+1),
             ylim= c(min(SL_time$y)-1, max(SL_time$y)+1))
)


##Inspect time series####

ggplot()+
  geom_line(data=SL_time, aes(DateTime, y,  color=id))+
  scale_color_viridis_d()+
  theme_bw()+
  facet_wrap(~id, scales= "free")

ggplot()+
  geom_line(data=SL_time, aes(DateTime, x,  color=id))+
  scale_color_viridis_d()+
  theme_bw()+
  facet_wrap(~id, scales= "free")


# Multiple imputation procedures ####
plot(table(diff(SL_time$DateTime)), xlim =c(0, 60),
     xlab= "time interval (hr)", ylab= "count")

SL_ade <- setNA(ltraj= as.ltraj(xy=SL_time[, c("utmx",
                                         "utmy")],
                               date=SL_time$DateTime,
                               id=SL_time$id),
                               
               date.ref = SL_time$DateTime[1],
               dt= 4, tol = 5, units= "hour")

## Add slope, aspect, elevation, temp information to the trajectory object##

SL_adena <- ld(SL_ade)[, c("id", "x", "y", "date")]
colnames(SL_adena) <-  c ("ID", "utmx", "utmy", "DateTime")

SL_adena$Temp <- NA
SL_adena$slope <- NA
SL_adena$aspect <- NA
SL_adena$Elevation <- NA
SL_adena$aspect[which(!is.na(SL_adena$utmx))] <- SL_time$aspect
SL_adena$Temp[which(!is.na(SL_adena$utmx))] <- SL_time$Temp
SL_adena$slope[which(!is.na(SL_adena$utmx))] <- SL_time$slope
SL_adena$Elevation[which(!is.na(SL_adena$utmx))] <- SL_time$Elevation
SL_adena$tod <- hour(SL_adena$DateTime)
SL_adena = SL_adena %>% 
  mutate(Sex = ifelse(ID == 13647, "Male", "Female"))
head(SL_adena, 10)
view(SL_adena)


## Female####
SL_fem <- SL_adena %>%
  subset(ID != "17103") %>% 
  subset(ID != "13647")

unique(SL_fem$ID)

##Male####
SL_mal <- SL_adena %>% 
  subset(ID=="13647")

unique(SL_mal$ID)

plot(table(diff(SL_adena$DateTime)), xlim =c(0, 60),
     xlab= "time interval (hr)", ylab= "count")

dist <- list(step="gamma", angle="“wrpcauchy”")


#Crawl####

##for female
SL_fem <- SL_fem%>%
  rename(ID=ID)
str(SL_fem)
crw_out_fem <- crawlWrap(obsData = SL_fem, timeStep = "4 hour",
                     Time.name = "DateTime", coord = c("utmx", "utmy"))
##for male 
SL_mal <- SL_mal%>%
  rename(ID=ID)
str(SL_mal)
crw_out_mal <- crawlWrap(obsData = SL_mal, timeStep = "4 hour",
                     Time.name = "DateTime", coord = c("utmx", "utmy"))

#plot.crwData(crw_out)
##for female
SL_fem_hmm1 <-  prepData(data=SL_fem,  type = "UTM", coordNames = c("utmx", "utmy"))
head(SL_fem_hmm1)
class(SL_fem_hmm1)
print(SL_fem_hmm1$step, 10)

##for male
SL_mal_hmm1 <-  prepData(data=SL_mal,  type = "UTM", coordNames = c("utmx", "utmy"))
head(SL_mal_hmm1)
class(SL_mal_hmm1)
print(SL_mal_hmm1$step, 10)

prep_fem <- prepData(crw_out_fem)
prep_mal <- prepData(crw_out_mal)

##Plot time series and distribution of step length####

#for female
ggplot(SL_fem_hmm1, aes(step))+
  geom_histogram(binwidth = 500)+
  theme_bw()

ggplot(SL_fem_hmm1, aes(DateTime, step))+
  geom_line()+
  theme_bw()+
  facet_wrap(~ID, scales= "free_x")

#for male
ggplot(SL_mal_hmm1, aes(step))+
  geom_histogram(binwidth = 500)+
  theme_bw()

ggplot(SL_mal_hmm1, aes(DateTime, step))+
  geom_line()+
  theme_bw()+
  facet_wrap(~ID, scales= "free_x")


##Plot time series and distribution of turning angles####
#for female
ggplot(SL_fem_hmm1, aes(angle))+
  geom_histogram(binwidth = pi/8)+
  theme_bw()

ggplot(SL_fem_hmm1, aes(DateTime, angle))+
  geom_line()+
  theme_bw()+
  facet_wrap(~ID, scales= "free_x")

class(SL_fem_hmm1)

#for male
ggplot(SL_mal_hmm1, aes(angle))+
  geom_histogram(binwidth = pi/8)+
  theme_bw()

ggplot(SL_mal_hmm1, aes(DateTime, angle))+
  geom_line()+
  theme_bw()+
  facet_wrap(~ID, scales= "free_x")

class(SL_mal_hmm1)

# Plot histogram of step lengths####
hist(SL_fem_hmm1$step,freq= TRUE, xlab = "step length", main = "")
hist(SL_mal_hmm1$step,freq= TRUE, xlab = "step length", main = "")

#Temperature####
#for female
time=as.POSIXct(SL_fem_hmm1$LMT_Time,
                format="%H:%M:%S", tz="UTC")
SL_fem_hmm1 $yday <- yday(SL_fem_hmm1$DateTime)
SL_fem_hmm1 $hr <- hour(time)
plot(SL_fem_hmm1 $yday, SL_fem_hmm1 $Temp)

#for male
time=as.POSIXct(SL_mal_hmm1$LMT_Time,
                format="%H:%M:%S", tz="UTC")
SL_mal_hmm1$yday <- yday(SL_mal_hmm1$DateTime)
SL_mal_hmm1$hr <- hour(time)
plot(SL_mal_hmm1$yday, SL_mal_hmm1$Temp)


#For female ####
## Starting values for the step length parameters####
stepMeanfe2 <- c(50, 512) # initial means (one for each state)
stepSDfe2 <- c(50 , 512) # initial standard deviations (one for each state)
stepParfe2 <- c(stepMeanfe2, stepSDfe2)

stepMeanfec2 <- c(50 , 512)  # initial means (one for each state)
stepSDfec2 <- c(50 , 512) # initial standard deviations (one for each state)
stepParfec2 <- c(stepMeanfec2, stepSDfec2)
zeromassfec2 <- c(0.0031, 0.0001)


## Indices of steps of length zero####
whichzero <- which(prep_fem$step == 0)

## Proportion of steps of length zero in the data set####
length(whichzero)/nrow(prep_fem)

zeromassfe2 <- c(0.0031, 0.0001)

## Plot histogram of turning angles####
hist(prep_fem$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")

## Starting values for the turning angle parameters####
angleMeanfe2 <- c(0.5, 0.2) # initial means (one for each state)
angleConfe2 <- c(0.1, 0.2) # initial concentrations (one for each state)
angleParfe2 <- c(angleMeanfe2, angleConfe2)

# For reproducibility
set.seed(12345)


##Fit hmm 2-state####
tic()

SL_fem_2st_hmm1<- MIfitHMM(miData=crw_out_fem,  nSims= 15, ncores=3, nbStates=2,
                 dist = list(step="gamma", angle= "wrpcauchy"),
                 Par0= list(step=c(stepMeanfe2,stepSDfe2,zeromassfe2), angle=angleMeanfe2), 
                 stateNames = c("Resting", "Hunting"),
                 retryFits = 10) 
toc()
### 7 mins
SL_fem_2st_hmm1

library(car)
plot(SL_fem_2st_hmm1)

plotStates(SL_fem_2st_hmm1,  ask = FALSE)
plotPR(SL_fem_2st_hmm1, ncores=5)


##Fit hmm 3-state####

angleMeanfe3 <-  c(0.8, 0.4, 0.2)
angleParfe3 <-  c(0.8,0.4,0.2, 0.5, 0.4, 0.7)

stepMeanfe3<-c(50, 290, 600) # means of gamma distribution 
stepSDfe3<-c(50, 290, 600) # std. dev. of gamma distribution 
zeromassfe3 <-  c(0.003, 0.0001, 0.0005)

stepParfe3<-c(stepMeanfe3,stepSDfe3)

# For reproducibility
set.seed(12345)
tic()
SL_fem_3st_hmm1 <- MIfitHMM(miData=crw_out_fem,  nSims= 15, ncores=3, nbStates=3,
                 dist = list(step="gamma", angle= "wrpcauchy"),
                 Par0= list(step=c(stepMeanfe3,stepSDfe3,zeromassfe3), angle=angleMeanfe3), 
                 stateNames = c("Resting", "Hunting" ,"Exploratory"),
                 retryFits = 10)
toc()
### 35 mins
SL_fem_3st_hmm1
class(SL_fem_3st_hmm1)
plot(SL_fem_3st_hmm1, plotCI= TRUE)
plotPR(SL_fem_3st_hmm1, ncores=5)
AICweights(SL_fem_2st_hmm1,SL_fem_3st_hmm1)


# Log-likelihood values from each imputation
param_2st_fem <- 11
param_3st_fem <- 20

bic_2st_fem <- -2 * mean(c(-21538.61, -21530.66, -21564.54, -21538.53, -21559.87, 
                           -21554.33, -21530.99, -21556.13, -21531.73, -21551.68, 
                           -21540.77, -21563.34, -21566.19, -21542, -21537.11))+ 
                      log(nrow(SL_fem)) *  param_2st_fem
bic_2st_fem 


bic_3st_fem <- -2 * mean(c(-21416.15, -21399.4, -21414.43, -21407.16, -21424.78, 
                           -21425.97, -21409.03, -21402.74, -21423.26, -21422.24, 
                           -21428.1, -21418.68, -21417.71, -21424.67, -21421.8))+  
                           log(nrow(SL_fem)) * param_3st_fem
bic_3st_fem 


##2 state model with co-variates####

formula_el <- ~Elevation
formula_sl <- ~slope
formula_el_sl <- ~Elevation+ slope
formula_elsl <-  ~Elevation*slope
formula_assl <- ~aspect*slope
formula_as_sl <- ~aspect+slope
formula_as <- ~aspect
formula_tod <- ~ cosinor(tod, period= 24)
nbCovs <- 2
nbStates2 <- 2

head(crw_out_fem)

###slope ####
SL_sl_data<-prepData(crw_out_fem,covNames=c("slope"))

#plot histogram for step and angles
hist(SL_sl_data$step, xlab = "step length", main = "")
hist(SL_sl_data$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_sl_hmm1<-fitHMM(SL_sl_data,
                nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                Par0= list(step=c(stepMeanfec2,stepSDfec2,zeromassfec2), angle=angleParfe2), 
                stateNames = c("Resting", "Hunting"),
                formula=formula_sl,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_sl_hmm1)

# extract estimates from 'SL_2st_sl_hmm1'
Parfe2 <- getPar(SL_2st_sl_hmm1)
# Fit nSims=15 imputations of the position process
SL_2st_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                 nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                 Par0=Parfe2$Par,beta0=Parfe2$beta,delta0=Parfe2$delta,
                 formula=formula_sl,estAngleMean=list(angle=TRUE),
                 covNames=c("slope"))   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_sl_mifits)
plot(SL_2st_sl_mifits)
plotPR(SL_2st_sl_mifits, ncores=5) ##takes upto 6 mins
plotStationary(SL_2st_sl_mifits, CI= TRUE)
timeInStates(SL_2st_sl_mifits)

###elevation ####
SL_el_data<-prepData(crw_out_fem,covNames=c("Elevation"))
#plot histogram for step and angles
hist(SL_el_data$step, xlab = "step length", main = "")
hist(SL_el_data$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_el_hmm1<-fitHMM(SL_el_data,
                          nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanfe2,stepSDfe2,zeromassfe2), angle=angleParfe2), 
                          stateNames = c("Resting", "Hunting"),
                          formula=formula_el,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_el_hmm1)

# extract estimates from 'SL_2st_el_hmm1'
Parfe2 <- getPar(SL_2st_el_hmm1)

# Fit nSims=15 imputations of the position process
SL_2st_el_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                              nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parfe2$Par,beta0=Parfe2$beta,delta0=Parfe2$delta,
                              formula=formula_el,estAngleMean=list(angle=TRUE),
                              covNames="Elevation")   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_el_mifits)
plot(SL_2st_el_mifits)
plotPR(SL_2st_el_mifits, ncores=5) ##takes upto 6 mins
stationary(SL_2st_el_mifits)
timeInStates(SL_2st_el_mifits)

###aspect ####
SL_as_data<-prepData(crw_out_fem,covNames=c("aspect"))
#plot histogram for step and angles
hist(SL_as_data$step, xlab = "step length", main = "")
hist(SL_as_data$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_as_hmm1<-fitHMM(SL_as_data,
                       nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanfe2,stepSDfe2,zeromassfe2), angle=angleParfe2), 
                       stateNames = c("Resting", "Hunting"),
                       formula=formula_as,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_as_hmm1)

# extract estimates from 'SL_2st_as_hmm1'
Parfe2 <- getPar(SL_2st_as_hmm1)

# Fit nSims=15 imputations of the position process
SL_2st_as_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                           nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parfe2$Par,beta0=Parfe2$beta,delta0=Parfe2$delta,
                           formula=formula_as,estAngleMean=list(angle=TRUE),
                           covNames="aspect")   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_as_mifits)
plot(SL_2st_as_mifits)
plotPR(SL_2st_as_mifits, ncores=5) ##takes upto 6 mins
stationary(SL_2st_as_mifits)
timeInStates(SL_2st_as_mifits)

### elevation and slope####
SL_el_sl_data<-prepData(crw_out_fem,covNames=c("Elevation", "slope"))
#plot histogram for step and angles
hist(SL_el_sl_data$step, xlab = "step length", main = "")
hist(SL_el_sl_data$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_el_sl_hmm1<-fitHMM(SL_el_sl_data,
                          nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanfec2,stepSDfec2,zeromassfec2), angle=angleParfe2), 
                          stateNames = c("Resting", "Hunting"),
                          formula=formula_el_sl,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_el_sl_hmm1)

# extract estimates from 'SL_2st_el_sl_hmm1'
Parfe2 <- getPar(SL_2st_el_sl_hmm1)

# Fit nSims=15 imputations of the position process
SL_2st_el_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                              nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parfe2$Par,beta0=Parfe2$beta,delta0=Parfe2$delta,
                              formula=formula_el_sl,estAngleMean=list(angle=TRUE),
                              covNames=c("Elevation","slope"))   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_el_sl_mifits)
plot(SL_2st_el_sl_mifits)
plotPR(SL_2st_el_sl_mifits, ncores=5) ##takes upto 6 mins
stationary(SL_2st_el_sl_mifits)
timeInStates(SL_2st_el_sl_mifits)

### elevation * slope ####
SL_elsl_data<-prepData(crw_out_fem,covNames=c("Elevation", "slope"))
#plot histogram for step and angles
hist(SL_elsl_data$step, xlab = "step length", main = "")
hist(SL_elsl_data$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_elsl_hmm1<-fitHMM(SL_elsl_data,
                          nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanfec2,stepSDfec2,zeromassfec2), angle=angleParfe2), 
                          stateNames = c("Resting", "Hunting"),
                          formula=formula_elsl,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_elsl_hmm1)

# extract estimates from 'SL_2st_elsl_hmm1'
Parfe2 <- getPar(SL_2st_elsl_hmm1)

# Fit nSims=15 imputations of the position process
SL_2st_elsl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                              nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parfe2$Par,beta0=Parfe2$beta,delta0=Parfe2$delta,
                              formula=formula_elsl,estAngleMean=list(angle=TRUE),
                              covNames=c("Elevation","slope"))   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_elsl_mifits)
plot(SL_2st_elsl_mifits)
plotPR(SL_2st_elsl_mifits, ncores=5) ##takes upto 6 mins
stationary(SL_2st_elsl_mifits)
timeInStates(SL_2st_elsl_mifits)

##3 state model with co-variates####

formula_el <- ~Elevation
formula_sl <- ~slope
formula_elsl <-  ~Elevation*slope
formula_el_sl <- ~Elevation+slope
formula_assl <- ~aspect*slope
formula_as_sl <- ~aspect+slope
formula_as <- ~aspect
formula_tod <- ~ cosinor(tod, period= 24)
formula_tod_sl <- ~slope +cosinor(tod, period= 24)
formula_as_el_sl <- ~aspect+slope+Elevation
formula_tod_el_sl <- ~cosinor(tod, period= 24)+slope+Elevation
nbCovs <- 2
nbStates3 <- 3

###elevation####
SL_el_data<-prepData(crw_out_fem,covNames=c("Elevation"))
SL_3st_el_hmm1<-fitHMM(SL_el_data,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_el,estAngleMean=list(angle=TRUE))
                        ###takes upto 8 mins

AIC(SL_3st_el_hmm1) #58246.84
print(SL_3st_el_hmm1)

par_fem_el <- length(SL_3st_el_hmm1$mod$estimate)
bic_3st_el_fem <- -2 * -20535.25+ log(nrow(SL_fem)) * par_fem_el
bic_3st_el_fem

# extract estimates from 'SL_3st_el_hmm1'
Parfe3 <- getPar(SL_3st_el_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_el_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                          nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                          formula=formula_el,estAngleMean=list(angle=TRUE),
                          covNames=c("Elevation"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_el_mifits)
plot(SL_3st_el_mifits)
plotPR(SL_3st_el_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_el_mifits) 
timeInStates(SL_3st_el_mifits)

###tod####
SL_tod_data<-prepData(crw_out_fem,covNames=c("tod"))
SL_3st_tod_hmm1<-fitHMM(SL_tod_data,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_tod,estAngleMean=list(angle=TRUE))
###takes upto 8 mins
plotStationary(SL_3st_tod_hmm1, plotCI = TRUE)
print(SL_3st_tod_hmm1)
par_fem_tod <- length(SL_3st_tod_hmm1$mod$estimate)
bic_3st_tod_fem <- -2 * -20334.37 + log(nrow(SL_fem)) *  par_fem_tod
bic_3st_tod_fem
# extract estimates from 'SL_3st_tod_hmm1'
Parfe3 <- getPar(SL_3st_tod_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_tod_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                           nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                           formula=formula_tod,estAngleMean=list(angle=TRUE),
                           covNames=c("tod"))   ### takes upto 10 mins

# print pooled estimates
class(SL_3st_tod_mifits)
print(SL_3st_tod_mifits)
plot(SL_3st_tod_mifits)

plotPR(SL_3st_tod_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_tod_mifits) 
timeInStates(SL_3st_tod_mifits)
plotStationary(SL_3st_tod_mifits, plotCI = TRUE) 


###stationary probability
stationary_prob_1 <- stationary(SL_3st_tod_mifits)

stationary_prob_df_1 <- as.data.frame(stationary_prob_1)

# bind columns
stationary_prob_df_1 <- cbind(ID_PE = 1:nrow(stationary_prob_df_1), stationary_prob_df_1)

SL_fem1 <- cbind(ID_PE = 1:nrow(SL_fem), SL_fem)

SL_fem2 <- SL_fem1 %>% dplyr::select(ID_PE, tod)

# Join the data frames
stationary_prob_df_1 <- stationary_prob_df_1 %>% 
  left_join(SL_fem2, by = "ID_PE")

# Reshape the data for ggplot
stationary_prob_long_1 <- stationary_prob_df_1 %>%
  pivot_longer(cols = starts_with("state"), names_to = "State", values_to = "Probability")

# Calculate mean and standard error for confidence intervals
stationary_prob_summary_1 <- stationary_prob_long_1 %>%
  group_by(State, tod) %>%
  summarise(
    mean_prob = mean(Probability, na.rm = TRUE),
    se = sd(Probability, na.rm = TRUE) / sqrt(n()),
    .groups = 'drop'
  ) %>%
  mutate(
    upper_bound = mean_prob + qt(0.975, df = n() - 1) * se,  # 95% CI upper bound
    lower_bound = mean_prob - qt(0.975, df = n() - 1) * se   # 95% CI lower bound
  )
stationary_prob_summary_1


# Define custom colors
line_colors <- c("state.1" = "darkorange", "state.2" = "darkblue", "state.3" = "darkgreen")
fill_colors <- c("state.1" = "orange", "state.2" = "blue", "state.3" = "forestgreen")

# Plotting the smoothed lines with shaded confidence intervals
ggplot(stationary_prob_long_1, aes(x = tod, y = Probability, color = State, fill = State, group = State)) +
  # Smoothed lines with shaded confidence intervals
  geom_smooth(method = "loess", se = TRUE, size = 0.1, alpha = 0.2) +  
  labs(x = "Time of Day (hours)",
       y = "Stationary Probability") +
  scale_color_manual(values = line_colors) +  # Set line colors
  scale_fill_manual(values = fill_colors)+   # Set fill colors for confidence intervals
  ylim(0, 1) +  # Define y-axis limits (min = 0, max = 1) +   # Set fill colors for confidence intervals
  theme_classic() +
  theme(legend.position = c(1, 1),  # Position legend in the top right corner
        legend.justification = c(1.8, 1.4),
        legend.text = element_text(size = 20),  # Increase legend text size
        legend.title = element_text(size = 20),  # Increase legend title size
        legend.key.size = unit(1.5, "cm"),  # Increase size of legend keys
        axis.title = element_text(size = 20),  # Increase axis title size
        axis.text = element_text(size = 20))  # Increase axis label text size  

###aspect ####
SL_as_data<-prepData(crw_out_fem,covNames=c("aspect"))
SL_3st_as_hmm1<-fitHMM(SL_as_data,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_as,estAngleMean=list(angle=TRUE))
###takes upto 8 mins

print(SL_3st_as_hmm1)
par_fem_as <- length(SL_3st_as_hmm1$mod$estimate)
bic_3st_as_fem <- -2 * -29220.4  + log(nrow(SL_fem)) *  par_fem_as
bic_3st_as_fem

# extract estimates from 'SL_3st_as_hmm1'
Parfe3 <- getPar(SL_3st_as_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_as_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                           nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                           formula=formula_as,estAngleMean=list(angle=TRUE),
                           covNames=c("Sex"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_as_mifits)
plot(SL_3st_as_mifits)
plotPR(SL_3st_as_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_as_mifits) 
timeInStates(SL_3st_as_mifits)


###slope####
SL_sl_data<-prepData(crw_out_fem,covNames=c("slope"))
SL_3st_sl_hmm1<-fitHMM(SL_sl_data,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_sl,estAngleMean=list(angle=TRUE),
                       retryfits=10)  ###takes upto 8 mins

print(SL_3st_sl_hmm1)
par_fem_sl <- length(SL_3st_sl_hmm1$mod$estimate)
bic_3st_sl_fem <- -2 * -20399 + log(nrow(SL_fem)) *  par_fem_sl
bic_3st_sl_fem

# extract estimates from 'SL_3st_sl_hmm1'
Parfe3 <- getPar(SL_3st_sl_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                           nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                           formula=formula_sl,estAngleMean=list(angle=TRUE),
                           covNames=c("slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_sl_mifits)
plot(SL_3st_sl_mifits, plotCI= TRUE)

plotPR(SL_3st_sl_mifits, ncores=15) ##takes upto 6 mins

plotStationary(SL_3st_sl_mifits, plotCI = TRUE, legend.pos= "top") 
timeInStates(SL_3st_sl_mifits)

### slope and elevation####
SL_el_sl_data<-prepData(crw_out_fem,covNames=c("Elevation", "slope"))
SL_3st_el_sl_hmm1<-fitHMM(SL_el_sl_data,
                          nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                          stateNames = c("Resting", "Hunting", "Exploratory"),
                          formula=formula_el_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_el_sl_hmm1)
par_fem_slel <- length(SL_3st_el_sl_hmm1$mod$estimate)
bic_3st_slel_fem <- -2 * -20431.2 + log(nrow(SL_fem)) *  par_fem_slel
bic_3st_slel_fem

# extract estimates from 'SL_3st_el_sl_hmm1'
Parfe3 <- getPar(SL_3st_el_sl_hmm1)

# Fit nSims=15 imputations of the position process slope and elevation
SL_3st_el_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                              nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                              formula=formula_el_sl,estAngleMean=list(angle=TRUE),
                              covNames=c("Elevation", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_el_sl_mifits)
plot(SL_3st_el_sl_mifits)
plotPR(SL_3st_el_sl_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_el_sl_mifits) 
timeInStates(SL_3st_el_sl_mifits)


###slope and tod####
SL_tod_sl_data<-prepData(crw_out_fem,covNames=c("slope", "tod"))
SL_3st_tod_sl_hmm1<-fitHMM(SL_tod_sl_data,
                          nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                          stateNames = c("Resting", "Hunting", "Exploratory"),
                          formula=formula_tod_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_tod_sl_hmm1)
par_fem_sltod <- length(SL_3st_tod_sl_hmm1$mod$estimate)
bic_3st_sltod_fem <- -2 * -20389.89 + log(nrow(SL_fem)) *  par_fem_sltod
bic_3st_sltod_fem
AIC(SL_3st_tod_sl_hmm1)

# extract estimates from 'SL_3st_tod_sl_hmm1'
Parfe3 <- getPar(SL_3st_tod_sl_hmm1)

# Fit nSims=15 imputations of the position process slope and tod
SL_3st_tod_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                              nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                              formula=formula_tod_sl,estAngleMean=list(angle=TRUE),
                              covNames=c("slope", "tod"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_tod_sl_mifits)
plot(SL_3st_tod_sl_mifits, plotCI = TRUE)

plotPR(SL_3st_tod_sl_mifits, ncores=5) ##takes upto 6 mins
plot(SL_3st_tod_sl_mifits, plotCI= TRUE, plotStationary= TRUE)
stationary(SL_3st_tod_sl_mifits) 
plotStationary(SL_3st_tod_sl_hmm1, plotCI = TRUE)

timeInStates(SL_3st_tod_sl_mifits)

### slope and aspect####
SL_as_sl_data<-prepData(crw_out_fem,covNames=c("aspect", "slope"))
SL_3st_as_sl_hmm1<-fitHMM(SL_as_sl_data,
                          nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                          stateNames = c("Resting", "Hunting", "Exploratory"),
                          formula=formula_as_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_as_sl_hmm1)
par_fem_slas <- length(SL_3st_as_sl_hmm1$mod$estimate)
bic_3st_slas_fem <- -2 * -20434.98  + log(nrow(SL_fem)) *  par_fem_slas
bic_3st_slas_fem
AIC(SL_3st_as_sl_hmm1)

# extract estimates from 'SL_3st_as_sl_hmm1'
Parfe3 <- getPar(SL_3st_as_sl_hmm1)

# Fit nSims=15 imputations of the position process slope and aspect
SL_3st_as_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                              nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                              formula=formula_as_sl,estAngleMean=list(angle=TRUE),
                              covNames=c("aspect", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_as_sl_mifits)
plot(SL_3st_as_sl_mifits)
plotPR(SL_3st_as_sl_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_as_sl_mifits) 
plotStationary(SL_3st_as_sl_mifits, plotCI = TRUE)
timeInStates(SL_3st_as_sl_mifits)


###slope * elevation####
SL_elsl_data<-prepData(crw_out_fem,covNames=c("Elevation","slope"))
SL_3st_elsl_hmm1<-fitHMM(SL_elsl_data,
                          nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                          stateNames = c("Resting", "Hunting", "Exploratory"),
                          formula=formula_elsl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_elsl_hmm1)

# extract estimates from 'SL_3st_elsl_hmm1'
Parfe3 <- getPar(SL_3st_elsl_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_elsl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                              nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                              formula=formula_elsl,estAngleMean=list(angle=TRUE),
                              covNames=c("Elevation", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_elsl_mifits)
plot(SL_3st_elsl_mifits)
plotPR(SL_3st_elsl_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_elsl_mifits) 
timeInStates(SL_3st_elsl_mifits)


### slope * aspect####
SL_assl_data<-prepData(crw_out_fem,covNames=c("aspect","slope"))
SL_3st_assl_hmm1<-fitHMM(SL_assl_data,
                             nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                             stateNames = c("Resting", "Hunting", "Exploratory"),
                             formula=formula_assl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_assl_hmm1)

# extract estimates from 'SL_3st_assl_hmm1'
Parfe3 <- getPar(SL_3st_assl_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_assl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                                 nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                                 Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                                 formula=formula_assl,estAngleMean=list(angle=TRUE),
                                 covNames=c("aspect", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_assl_mifits)
plot(SL_3st_assl_mifits)
plotPR(SL_3st_assl_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_assl_mifits) 
timeInStates(SL_3st_assl_mifits)


### slope + aspect + elevation####
SL_as_el_sl_data<-prepData(crw_out_fem,covNames=c("aspect","slope", "Elevation"))
SL_3st_as_el_sl_hmm1<-fitHMM(SL_as_el_sl_data,
                         nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                         Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                         stateNames = c("Resting", "Hunting", "Exploratory"),
                         formula=formula_as_el_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_as_el_sl_hmm1)
par_fem_slasel <- length(SL_3st_as_el_sl_hmm1$mod$estimate)
bic_3st_slasel_fem <- -2 *  + log(nrow(SL_fem)) *  par_fem_slasel
bic_3st_slasel_fem
AIC(SL_3st_as_el_sl_hmm1)

# extract estimates from 'SL_3st_as_el_sl_hmm1'
Parfe3 <- getPar(SL_3st_as_el_sl_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_as_el_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                             nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                             formula=formula_as_el_sl,estAngleMean=list(angle=TRUE),
                             covNames=c("aspect", "slope", "Elevation"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_as_el_sl_mifits)
plot(SL_3st_as_el_sl_mifits)
plotPR(SL_3st_as_el_sl_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_as_el_sl_mifits) 
timeInStates(SL_3st_as_el_sl_mifits)


### slope + tod + elevation####
SL_tod_el_sl_data<-prepData(crw_out_fem,covNames=c("tod","slope", "Elevation"))
SL_3st_tod_el_sl_hmm1<-fitHMM(SL_tod_el_sl_data,
                             nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0= list(step=c(stepMeanfe3,stepSDfe3, zeromassfe3), angle=angleParfe3), 
                             stateNames = c("Resting", "Hunting", "Exploratory"),
                             formula=formula_tod_el_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_tod_el_sl_hmm1)
par_fem_sltodel <- length(SL_3st_tod_el_sl_hmm1$mod$estimate)
bic_3st_sltodel_fem <- -2 * -20430.9  + log(nrow(SL_fem)) *  par_fem_sltodel
bic_3st_sltodel_fem

# extract estimates from 'SL_3st_tod_el_sl_hmm1'
Parfe3 <- getPar(SL_3st_tod_el_sl_hmm1)

# Fit nSims=15 imputations of the position process
SL_3st_tod_el_sl_mifits<-MIfitHMM(miData=crw_out_fem, nSims= 15, ncores=3,
                                 nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                                 Par0=Parfe3$Par,beta0=Parfe3$beta,delta0=Parfe3$delta,
                                 formula=formula_tod_el_sl,estAngleMean=list(angle=TRUE),
                                 covNames=c("tod", "slope", "Elevation"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_tod_el_sl_mifits)
plot(SL_3st_tod_el_sl_mifits)
plotPR(SL_3st_tod_el_sl_mifits, ncores=5) ##takes upto 6 mins

stationary(SL_3st_tod_el_sl_mifits) 
timeInStates(SL_3st_tod_el_sl_mifits)

##AIC####
AICweights(SL_fem_2st_hmm1, SL_fem_3st_hmm1)
AIC(SL_fem_2st_hmm1)#58658.67
AIC(SL_fem_3st_hmm1)# 58481.54##

AIC(SL_2st_el_hmm1) #60678.85
AIC(SL_2st_elsl_hmm1)# 60716.13
AIC(SL_2st_el_sl_hmm1)# 60682.85
AIC(SL_2st_sl_hmm1) #58650.18
AIC(SL_2st_as_hmm1) # 60493.35

AIC(SL_3st_el_hmm1) #nlm  59599.26
AIC(SL_3st_elsl_hmm1)# 61710.19
AIC(SL_3st_el_sl_hmm1)# 59941.36
AIC(SL_3st_sl_hmm1) #58390.97
AIC(SL_3st_as_hmm1)#58809.23
AIC(SL_3st_as_el_sl_hmm1) #58978.83
AIC(SL_3st_as_sl_hmm1)#58818.92
AIC(SL_3st_assl_hmm1)#nlm
AIC(SL_3st_aselsl_hmm1) #nlm 
AIC(SL_3st_tod_hmm1) # 58237.36
AIC(SL_3st_tod_sl_hmm1) #58399.72 ##
AIC(SL_3st_tod_el_sl_hmm1) #59869.16
AIC(SL_3st_tod_sl_hmm1)#58399.72



#For male ####
## Starting values for the step length parameters####
hist(SL_mal_hmm1$step)
stepMeanma2 <- c(15 , 512) # initial means (one for each state)
stepSDma2 <- c(15 , 512) # initial standard deviations (one for each state)
stepParma2 <- c(stepMeanfe2, stepSDfe2)

## Indices of steps of length zero####

whichzero <- which(SL_mal_hmm1$step == 0)

## Proportion of steps of length zero in the data set####

length(whichzero)/nrow(SL_mal_hmm1)

## Plot histogram of turning angles####
hist(SL_mal_hmm1$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")

## Starting values for the turning angle parameters####
angleMeanma2 <- c(0.6, 0.2) # initial means (one for each state)
angleConma2 <- c(0.2, 0.6) # initial concentrations (one for each state)
angleParma2 <- c(angleMeanma2, angleConma2)


# For reproducibility
set.seed(12345)
##Fit hmm 2-state####
tic()
SL_mal_2st_hmm1<- MIfitHMM(miData= crw_out_mal,  nSims= 15, ncores=3, nbStates=2,
                           dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0= list(step=c(stepMeanma2,stepSDma2), angle=angleMeanma2), 
                           stateNames = c("Resting", "Hunting"),
                           retryFits = 10) 
toc()
### 7 mins
SL_mal_2st_hmm1

plot(SL_mal_2st_hmm1)
plotStates(SL_mal_2st_hmm1,  ask = FALSE)
plotPR(SL_mal_2st_hmm1, ncores=5)

##Fit hmm 3-state####

angleMeanma3 <-  c(0.8, 0.4, 0.2)
angleParma3 <-  c(0.8, 0.4, 0.2, 0.4, 0.3, 0.7)

stepMeanma3<-c(15, 260, 600) # means of gamma distribution 
stepSDma3<-c(15, 260, 600) # std. dev. of gamma distribution 
stepParma3<-c(stepMeanma3,stepSDma3)

# For reproducibility
set.seed(12345)
tic()
SL_mal_3st_hmm1 <- MIfitHMM(miData= crw_out_mal, nSims= 15, ncores=3, nbStates=3,
                            dist = list(step="gamma", angle= "wrpcauchy"),
                            Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleMeanma3), 
                            stateNames = c("Resting", "Hunting" ,"Exploratory"),
                            retryFits = 10)
toc()
### 35 mins
SL_mal_3st_hmm1
plot(SL_mal_3st_hmm1)
plotPR(SL_mal_3st_hmm1, ncores=15)
stationary(SL_mal_3st_hmm1)
plotStationary(SL_mal_3st_hmm1, col = NULL, covs= NULL, plotCI = TRUE)

AICweights(SL_mal_2st_hmm1,SL_mal_3st_hmm1)


# Log-likelihood values from each imputation
param_2st_mal <- 9
param_3st_mal <- 17

bic_2st_mal <- -2 * mean(c(-38958.85,-39003.62,-38921.58,-38992.39,
                           -39006.72,-39028.46,-38994.33,-38959.78,-39005.16,
                           -39000.41,-39033.30,-39000.76, -38981.89,-38985.15))+ 
                          log(nrow(SL_mal)) *  param_2st_mal
bic_2st_mal


bic_3st_mal <- -2 * mean(c(-38662.96,-38716.02,-38640.28,-38691.63,
                           -38638.99,-38793.89,-38704.37,-38731.91,
                           -38699.59, -38702.95, -38710.31,-38666.59,
                           -38711.48, -38713.14,-38671.80))+  
                    log(nrow(SL_mal)) * param_3st_mal
bic_3st_mal

##2 state model with co-variates####

formula_el <- ~Elevation
formula_sl <- ~slope
formula_el_sl <- ~Elevation+ slope
formula_elsl <-  ~Elevation*slope
nbCovs <- 2
nbStates2 <- 2

head(crw_out_mal)

### slope ####
SL_sl_datam<-prepData(crw_out_mal,covNames=c("slope"))
#plot histogram for step and angles
hist(SL_sl_datam$step, xlab = "step length", main = "")
hist(SL_sl_datam$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_sl_hmm2<-fitHMM(SL_sl_datam,
                       nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanma2,stepSDma2), angle=angleParma2), 
                       stateNames = c("Resting", "Hunting"),
                       formula=formula_sl,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_sl_hmm2)

# extract estimates from 'SL_2st_sl_hmm2'
Parma2 <- getPar(SL_2st_sl_hmm2)

# Fit nSims=15 imputations of the position process
SL_2st_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                           nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parma2$Par,beta0=Parma2$beta,delta0=Parma2$delta,
                           formula=formula_sl,estAngleMean=list(angle=TRUE),
                           covNames=c("slope"))   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_sl_mifits2)
plot(SL_2st_sl_mifits2)
plotPR(SL_2st_sl_mifits2, ncores=5) ##takes upto 6 mins
stationary(SL_2st_sl_mifits2)
timeInStates(SL_2st_sl_mifits2)

### elevation####
SL_el_datam<-prepData(crw_out_mal,covNames=c("Elevation"))
#plot histogram for step and angles
hist(SL_el_datam$step, xlab = "step length", main = "")
hist(SL_el_datam$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_el_hmm2<-fitHMM(SL_el_datam,
                       nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanma2,stepSDma2), angle=angleParma2), 
                       stateNames = c("Resting", "Hunting"),
                       formula=formula_el,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_el_hmm2)

# extract estimates from 'SL_2st_el_hmm2'
Parma2 <- getPar(SL_2st_el_hmm2)

# Fit nSims=15 imputations of the position process
SL_2st_el_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                           nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parma2$Par,beta0=Parma2$beta,delta0=Parma2$delta,
                           formula=formula_el,estAngleMean=list(angle=TRUE),
                           covNames="Elevation")   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_el_mifits2)
plot(SL_2st_el_mifits2)
plotPR(SL_2st_el_mifits2, ncores=5) ##takes upto 6 mins
stationary(SL_2st_el_mifits2)
timeInStates(SL_2st_el_mifits2)

### elevation and slope####
SL_el_sl_datam<-prepData(crw_out_mal,covNames=c("Elevation", "slope"))
#plot histogram for step and angles
hist(SL_el_sl_datam$step, xlab = "step length", main = "")
hist(SL_el_sl_datam$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_el_sl_hmm2<-fitHMM(SL_el_sl_datam,
                          nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanma2,stepSDma2), angle=angleParma2), 
                          stateNames = c("Resting", "Hunting"),
                          formula=formula_el_sl,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_el_sl_hmm2)

# extract estimates from 'SL_2st_el_sl_hmm2'
Parma2 <- getPar(SL_2st_el_sl_hmm2)

# Fit nSims=15 imputations of the position process
SL_2st_el_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                              nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parma2$Par,beta0=Parma2$beta,delta0=Parma2$delta,
                              formula=formula_el_sl,estAngleMean=list(angle=TRUE),
                              covNames=c("Elevation","slope"))   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_el_sl_mifits2)
plot(SL_2st_el_sl_mifits2)
plotPR(SL_2st_el_sl_mifits2, ncores=5) ##takes upto 6 mins
stationary(SL_2st_el_sl_mifits2)
timeInStates(SL_2st_el_sl_mifits2)

### elevation * slope####
SL_elsl_datam<-prepData(crw_out_mal,covNames=c("Elevation", "slope"))
#plot histogram for step and angles
hist(SL_elsl_datam$step, xlab = "step length", main = "")
hist(SL_elsl_datam$angle, breaks = seq(-pi, pi, length = 15), xlab = "angle", main = "")
SL_2st_elsl_hmm2<-fitHMM(SL_elsl_datam,
                         nbStates=2,dist = list(step="gamma", angle= "wrpcauchy"),
                         Par0= list(step=c(stepMeanma2,stepSDma2), angle=angleParma2), 
                         stateNames = c("Resting", "Hunting"),
                         formula=formula_elsl,estAngleMean=list(angle=TRUE)) ##takes upto 5 mins

print(SL_2st_elsl_hmm2)

# extract estimates from 'SL_2st_elsl_hmm2'
Parma2 <- getPar(SL_2st_elsl_hmm2)

# Fit nSims=15 imputations of the position process
SL_2st_elsl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                             nbStates=nbStates2,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0=Parma2$Par,beta0=Parma2$beta,delta0=Parma2$delta,
                             formula=formula_elsl,estAngleMean=list(angle=TRUE),
                             covNames=c("Elevation","slope"))   ### takes upto 5 mins

# print pooled estimates
print(SL_2st_elsl_mifits2)
plot(SL_2st_elsl_mifits2)
plotPR(SL_2st_elsl_mifits2, ncores=5) ##takes upto 6 mins
stationary(SL_2st_elsl_mifits2)
timeInStates(SL_2st_elsl_mifits2)

##3 state model with co-variates####

formula_el <- ~Elevation
formula_sl <- ~slope
formula_elsl <-  ~Elevation*slope
formula_el_sl <- ~Elevation+slope
formula_tod <- ~ cosinor(tod, period= 24)
formula_tod_sl <- ~slope +cosinor(tod, period= 24)
formula_tod_el_sl <- ~cosinor(tod, period= 24) + slope+ Elevation
formula_as <- ~aspect
formula_as_sl <- ~aspect+slope
formula_assl <- ~aspect*slope
formula_aselsl <- ~aspect*slope*Elevation
formula_as_el_sl <- ~aspect+slope+Elevation
nbCovs <- 2
nbStates3 <- 3

### elevation####
SL_el_datam<-prepData(crw_out_mal,covNames=c("Elevation"))
SL_3st_el_hmm2<-fitHMM(SL_el_datam,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_el,estAngleMean=list(angle=TRUE))
###takes upto 8 mins

print(SL_3st_el_hmm2)
par_mal_el <- length(SL_3st_el_hmm2$mod$estimate)
bic_3st_el_mal <- -2 * -32709.06  + log(nrow(SL_fem)) *  par_mal_el
bic_3st_el_mal

# extract estimates from 'SL_3st_el_hmm2'
Parma3 <- getPar(SL_3st_el_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_el_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                           nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                           formula=formula_el,estAngleMean=list(angle=TRUE),
                           covNames=c("Elevation"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_el_mifits2)
plot(SL_3st_el_mifits2)
plotPR(SL_3st_el_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_el_mifits2) 
timeInStates(SL_3st_el_mifits2)
plotStationary(SL_3st_el_mifits2)

###tod####
SL_tod_datam<-prepData(crw_out_mal,covNames=c("tod"))
SL_3st_tod_hmm2<-fitHMM(SL_tod_datam,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_tod,estAngleMean=list(angle=TRUE))

###takes upto 8 mins
class(SL_3st_tod_hmm2)
print(SL_3st_tod_hmm2)
par_mal_tod <- length(SL_3st_tod_hmm2$mod$estimate)
bic_3st_tod_mal <- -2 * -32699.36  + log(nrow(SL_mal)) *  par_mal_tod
bic_3st_tod_mal


# extract estimates from 'SL_3st_tod_hmm2'
Parma3 <- getPar(SL_3st_tod_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_tod_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3, poolEstimates = T,
                            nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                            Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                            formula=formula_tod,estAngleMean=list(angle=TRUE),
                            covNames=c("tod"))   ### takes upto 10 mins


class(SL_3st_tod_mifits2)
timeInStates(SL_3st_tod_mifits2)
plotPR(SL_3st_tod_mifits2)
plotStationary(SL_3st_tod_mifits2, plotCI =  TRUE)


###stationary probability 
stationary_prob <- stationary(SL_3st_tod_mifits2)

stationary_prob_df <- as.data.frame(stationary_prob)

# bind columns
stationary_prob_df <- cbind(ID_PE = 1:nrow(stationary_prob_df), stationary_prob_df)

SL_mal1 <- cbind(ID_PE = 1:nrow(SL_mal), SL_mal)

SL_mal2 <- SL_mal1 %>% dplyr::select(ID_PE, tod)

# Join the dataframes
stationary_prob_df <- stationary_prob_df %>% 
  left_join(SL_mal2, by = "ID_PE")

# Reshape the data for ggplot
stationary_prob_long <- stationary_prob_df %>%
  pivot_longer(cols = starts_with("state"), names_to = "State", values_to = "Probability")

# Calculate mean and standard error for confidence intervals
stationary_prob_summary <- stationary_prob_long %>%
  group_by(State, tod) %>%
  summarise(
    mean_prob = mean(Probability, na.rm = TRUE),
    se = sd(Probability, na.rm = TRUE) / sqrt(n()),
    .groups = 'drop'
  ) %>%
  mutate(
    upper_bound = mean_prob + qt(0.975, df = n() - 1) * se,  # 95% CI upper bound
    lower_bound = mean_prob - qt(0.975, df = n() - 1) * se   # 95% CI lower bound
  )
stationary_prob_summary
sta_prob_summary


# Define custom colors
line_colors <- c("state.1" = "orange", "state.2" = "darkblue", "state.3" = "darkgreen")
fill_colors <- c("state.1" = "yellow", "state.2" = "blue", "state.3" = "green")

# Plotting the smoothed lines with shaded confidence intervals
ggplot(stationary_prob_long, aes(x = tod, y = Probability, color = State, fill = State, group = State)) +
  # Smoothed lines with shaded confidence intervals
  geom_smooth(method = "loess", se = TRUE, size = 0.1, alpha = 0.2) +  
  labs(x = "Time of Day (TOD)",
       y = "Stationary Probability") +
  scale_color_manual(values = line_colors) +  # Set line colors
  scale_fill_manual(values = fill_colors)+   # Set fill colors for confidence intervals
  ylim(0, 1) +  # Define y-axis limits (min = 0, max = 1) +   # Set fill colors for confidence intervals
  theme_classic() +
  theme(legend.position = c(1, 1),  # Position legend in the top right corner
        legend.justification = c(1.8, 1.4),
        legend.text = element_text(size = 20),  # Increase legend text size
        legend.title = element_text(size = 20),  # Increase legend title size
        legend.key.size = unit(1.5, "cm"),  # Increase size of legend keys
        axis.title = element_text(size = 20),  # Increase axis title size
        axis.text = element_text(size = 20)) # Adjust justification to the top right corner


print(stationary_prob_df )  # Check the summary of pooled estimates


###aspect####
SL_as_datam<-prepData(crw_out_mal,covNames=c("aspect"))
SL_3st_as_hmm2<-fitHMM(SL_as_datam,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_as,estAngleMean=list(angle=TRUE))
###takes upto 8 mins

print(SL_3st_as_hmm2)
par_mal_as <- length(SL_3st_as_hmm2$mod$estimate)
bic_3st_as_mal <- -2 * -32876.7  + log(nrow(SL_mal)) *  par_mal_as
bic_3st_as_mal
# extract estimates from 'SL_3st_as_hmm2'
Parma3 <- getPar(SL_3st_as_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_el_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                            nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                            Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                            formula=formula_as,estAngleMean=list(angle=TRUE),
                            covNames=c("aspect"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_el_mifits2)
plot(SL_3st_el_mifits2)
plotPR(SL_3st_el_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_el_mifits2) 
timeInStates(SL_3st_el_mifits2)


###slope####
SL_sl_datam<-prepData(crw_out_mal,covNames=c("slope"))
SL_3st_sl_hmm2<-fitHMM(SL_sl_datam,
                       nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                       Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                       stateNames = c("Resting", "Hunting", "Exploratory"),
                       formula=formula_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_sl_hmm2)
par_mal_sl <- length(SL_3st_sl_hmm2$mod$estimate)
bic_3st_sl_mal <- -2 * -32711.28   + log(nrow(SL_mal)) *  par_mal_sl
bic_3st_sl_mal

# extract estimates from 'SL_3st_sl_hmm2'
Parma3 <- getPar(SL_3st_sl_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                           nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                           Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                           formula=formula_sl,estAngleMean=list(angle=TRUE),
                           covNames=c("slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_sl_mifits2)
plot(SL_3st_sl_mifits2, plotCI= TRUE)
plotPR(SL_3st_sl_mifits2, ncores=15) ##takes upto 6 mins
pseudoRes(SL_3st_sl_mifits2)
stationary(SL_3st_sl_mifits2) 
plotStationary(SL_3st_sl_mifits2, plotCI =  TRUE, legend.pos = "center")
timeInStates(SL_3st_sl_mifits2)

### slope and elevation####
SL_el_sl_datam<-prepData(crw_out_mal,covNames=c("Elevation", "slope"))
SL_3st_el_sl_hmm2<-fitHMM(SL_el_sl_datam,
                          nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                          stateNames = c("Resting", "Hunting", "Exploratory"),
                          formula=formula_el_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_el_sl_hmm2)
par_mal_slel <- length(SL_3st_el_sl_hmm2$mod$estimate)
bic_3st_slel_mal <- -2 * -33079.39  + log(nrow(SL_mal)) *  par_mal_slel
bic_3st_slel_mal

# extract estimates from 'SL_3st_el_sl_hmm2'
Parma3 <- getPar(SL_3st_el_sl_hmm2)

# Fit nSims=15 imputations of the position process 
SL_3st_el_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                              nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                              formula=formula_el_sl,estAngleMean=list(angle=TRUE),
                              covNames=c("Elevation", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_el_sl_mifits2)
plot(SL_3st_el_sl_mifits2)
plotPR(SL_3st_el_sl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_el_sl_mifits2) 
timeInStates(SL_3st_el_sl_mifits2)


###slope and tod####
SL_tod_sl_datam<-prepData(crw_out_mal,covNames=c("slope", "tod"))
SL_3st_tod_sl_hmm2<-fitHMM(SL_tod_sl_datam,
                          nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                          stateNames = c("Resting", "Hunting", "Exploratory"),
                          formula=formula_tod_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_tod_sl_hmm2)
par_mal_sltod <- length(SL_3st_tod_sl_hmm2$mod$estimate)
bic_3st_sltod_mal <- -2 * -32709.19   + log(nrow(SL_mal)) *  par_mal_sltod
bic_3st_sltod_mal

AIC(SL_3st_tod_sl_hmm2)#65469.81

# extract estimates from 'SL_3st_tod_sl_hmm2'
Parma3 <- getPar(SL_3st_tod_sl_hmm2)

# Fit nSims=15 imputations of the position process 
SL_3st_tod_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3, 
                               nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                               Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                               formula=formula_tod_sl,estAngleMean=list(angle=TRUE),
                               covNames=c("tod", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_tod_sl_mifits2)
plot(SL_3st_tod_sl_mifits2)
plotPR(SL_3st_tod_sl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_tod_sl_mifits2) 
timeInStates(SL_3st_tod_sl_mifits2)

### slope and aspect####
SL_as_sl_datam<-prepData(crw_out_mal,covNames=c("aspect", "slope"))
SL_3st_as_sl_hmm2<-fitHMM(SL_as_sl_datam,
                          nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                          Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                          stateNames = c("Resting", "Hunting", "Exploratory"),
                          formula=formula_as_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_as_sl_hmm2)
par_mal_slas <- length(SL_3st_as_sl_hmm2$mod$estimate)
bic_3st_slas_mal <- -2 * -32706.44 + log(nrow(SL_mal)) *  par_mal_slas
bic_3st_slas_mal

# extract estimates from 'SL_3st_as_sl_hmm2'
Parma3 <- getPar(SL_3st_as_sl_hmm2)

# Fit nSims=15 imputations of the position process 
SL_3st_as_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                               nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                               Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                               formula=formula_as_sl,estAngleMean=list(angle=TRUE),
                               covNames=c("aspect", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_as_sl_mifits2)
plot(SL_3st_as_sl_mifits2)
plotPR(SL_3st_as_sl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_as_sl_mifits2) 
timeInStates(SL_3st_as_sl_mifits2)


### slope * elevation####
SL_elsl_datam<-prepData(crw_out_mal,covNames=c("Elevation","slope"))
SL_3st_elsl_hmm2<-fitHMM(SL_elsl_datam,
                         nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                         Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                         stateNames = c("Resting", "Hunting", "Exploratory"),
                         formula=formula_elsl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_elsl_hmm2)

# extract estimates from 'SL_3st_elsl_hmm2'
Parma3 <- getPar(SL_3st_elsl_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_elsl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                             nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                             formula=formula_elsl,estAngleMean=list(angle=TRUE),
                             covNames=c("Elevation", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_elsl_mifits2)
plot(SL_3st_elsl_mifits2)
plotPR(SL_3st_elsl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_elsl_mifits2) 
timeInStates(SL_3st_elsl_mifits2)

### aspect * slope####
SL_assl_datam<-prepData(crw_out_mal,covNames=c("aspect","slope"))
SL_3st_assl_hmm2<-fitHMM(SL_assl_datam,
                         nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                         Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                         stateNames = c("Resting", "Hunting", "Exploratory"),
                         formula=formula_assl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_assl_hmm2)

# extract estimates from 'SL_3st_assl_hmm2'
Parma3 <- getPar(SL_3st_assl_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_assl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                              nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                              Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                              formula=formula_elsl,estAngleMean=list(angle=TRUE),
                              covNames=c("aspect", "slope"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_assl_mifits2)
plot(SL_3st_assl_mifits2)
plotPR(SL_3st_assl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_assl_mifits2) 
timeInStates(SL_3st_assl_mifits2)


### slope + aspect + elevation####
SL_as_el_sl_datam<-prepData(crw_out_mal,covNames=c("aspect","slope", "Elevation"))
SL_3st_as_el_sl_hmm2<-fitHMM(SL_as_el_sl_datam,
                             nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                             stateNames = c("Resting", "Hunting", "Exploratory"),
                             formula=formula_as_el_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_as_el_sl_hmm2)
par_mal_sltodas <- length(SL_3st_as_el_sl_hmm2$mod$estimate)
bic_3st_sltodas_mal <- -2 * -33265.57   + log(nrow(SL_mal)) *  par_mal_sltodas
bic_3st_sltodas_mal

# extract estimates from 'SL_3st_as_el_sl_hmm2'
Parma3 <- getPar(SL_3st_as_el_sl_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_as_el_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                                 nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                                 Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                                 formula=formula_as_el_sl,estAngleMean=list(angle=TRUE),
                                 covNames=c("aspect", "slope", "Elevation"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_as_el_sl_mifits2)
plot(SL_3st_as_el_sl_mifits2)
plotPR(SL_3st_as_el_sl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_as_el_sl_mifits2) 
timeInStates(SL_3st_as_el_sl_mifits2)

### slope + elevation + tod####
SL_tod_el_sl_datam<-prepData(crw_out_mal,covNames=c("tod","slope", "Elevation"))
SL_3st_tod_el_sl_hmm2<-fitHMM(SL_tod_el_sl_datam,
                             nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                             stateNames = c("Resting", "Hunting", "Exploratory"),
                             formula=formula_tod_el_sl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_tod_el_sl_hmm2)
par_mal_sltodel <- length(SL_3st_tod_el_sl_hmm2$mod$estimate)
bic_3st_sltodel_mal <- -2 * -33075.35   + log(nrow(SL_mal)) *  par_mal_sltodel
bic_3st_sltodel_mal

# extract estimates from 'SL_3st_tod_el_sl_hmm2'
Parma3 <- getPar(SL_3st_tod_el_sl_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_tod_el_sl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                                  nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                                  Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                                  formula=formula_tod_el_sl,estAngleMean=list(angle=TRUE),
                                  covNames=c("tod", "slope", "Elevation"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_tod_el_sl_mifits2)
plot(SL_3st_tod_el_sl_mifits2)
plotPR(SL_3st_tod_el_sl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_tod_el_sl_mifits2) 
timeInStates(SL_3st_tod_el_sl_mifits2)


### slope * aspect * elevation####
SL_aselsl_datam<-prepData(crw_out_mal,covNames=c("aspect","slope", "Elevation"))
SL_3st_aselsl_hmm2<-fitHMM(SL_aselsl_datam,
                             nbStates=3,dist = list(step="gamma", angle= "wrpcauchy"),
                             Par0= list(step=c(stepMeanma3,stepSDma3), angle=angleParma3), 
                             stateNames = c("Resting", "Hunting", "Exploratory"),
                             formula=formula_aselsl,estAngleMean=list(angle=TRUE))  ###takes upto 8 mins

print(SL_3st_aselsl_hmm2)

# extract estimates from 'SL_3st_aselsl_hmm2'
Parma3 <- getPar(SL_3st_aselsl_hmm2)

# Fit nSims=15 imputations of the position process
SL_3st_aselsl_mifits2<-MIfitHMM(miData=crw_out_mal, nSims= 15, ncores=3,
                                  nbStates=nbStates3,dist = list(step="gamma", angle= "wrpcauchy"),
                                  Par0=Parma3$Par,beta0=Parma3$beta,delta0=Parma3$delta,
                                  formula=formula_aselsl,estAngleMean=list(angle=TRUE),
                                  covNames=c("aspect", "slope", "Elevation"))   ### takes upto 10 mins

# print pooled estimates
print(SL_3st_aselsl_mifits2)
plot(SL_3st_aselsl_mifits2)
plotPR(SL_3st_aselsl_mifits2, ncores=5) ##takes upto 6 mins

stationary(SL_3st_aselsl_mifits2) 
timeInStates(SL_3st_aselsl_mifits2)

##AIC####
AICweights(SL_mal_2st_hmm1, SL_mal_3st_hmm1)
AIC(SL_mal_2st_hmm1) #66421.14
AIC(SL_mal_3st_hmm1) #64884.64
AIC(SL_2st_el_hmm2) #66431.13
AIC(SL_2st_elsl_hmm2)# 70475.21
AIC(SL_2st_el_sl_hmm2)# 66581.32
AIC(SL_2st_sl_hmm2) # 66423.11

AIC(SL_3st_el_hmm2) #66113.37
AIC(SL_3st_elsl_hmm2)# 69504.66
AIC(SL_3st_el_sl_hmm2)#  66222.79
AIC(SL_3st_sl_hmm2) #65474.56 ##
AIC(SL_3st_el_hmm3) #65805.4
AIC(SL_3st_as_sl_hmm2)# 65476.89
AIC(SL_3st_assl_hmm2)#65763.79
AIC(SL_3st_as_el_sl_hmm2)#65763.79
AIC(SL_3st_aselsl_hmm2) #70244.66
AIC(SL_3st_tod_hmm2) #65462.73
AIC(SL_3st_tod_sl_hmm2)#65482.39
AIC(SL_3st_tod_el_sl_hmm2)#66226.7






#Home range concept ####
library(readxl)
library(sf)
library(ggspatial)
library(ggmap)
library(lwgeom)
library(units)
library(adehabitatLT)
library(adehabitatHR)
library(tidyverse)


# Define CRS for WGS84
wgs1984.proj <- st_crs("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")

# Define CRS for UTM Zone 45
UTMZ45 <- st_crs("+proj=utm +zone=45 +datum=WGS84 +units=m +no_defs")


# Importation of data SL (SL.xls) 

SL <- read_excel(file.choose(), 1)
SL <- SL %>% 
  subset(id!= "17103") %>% 
  mutate(id = ifelse(id == "13646", "13647", id))

head(SL)
str(SL)
SL$Date2 <- as.POSIXct(strptime(SL$DateTime, 
                                format = "%Y-%m-%d %H:%M:%S", 
                                tz = "GMT"))
SL$Date <- as.POSIXct(strptime(SL$LMT_Date, format = "%Y-%m-%d", 
                               tz = "GMT"))
SL$Hour <- as.numeric(format(strptime(SL$DateTime, 
                                       format = "%Y-%m-%d %H:%M:%S", 
                                       tz = "GMT"), "%H"))
SL <- mutate(SL, Animal = factor(id))
str(SL)
SL_attr_DD <- st_as_sf(data.frame(SL), coords = c("x", "y"), crs = wgs1984.proj)
class(SL_attr_DD)
SL_attr_DD

SL_attr <- st_transform(SL_attr_DD, UTMZ45)

ggplot() + 
  geom_sf(data = st_as_sf(SL_attr), aes(pch = Animal, color = -DOP), 
          alpha = 0.5, show.legend = 'point', inherit.aes = F) +
  coord_sf(label_axes = "ENEN") +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering()) +
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5)) 

## imprecise data####
SL_attr_imprecise <- SL_attr |> 
  dplyr::filter(DOP > 5.2)
dim(SL_attr_imprecise)

ggplot() + 
  geom_sf(data = st_as_sf(SL_attr_imprecise), 
          aes(pch = Animal, color = -DOP), alpha = 0.5, 
          show.legend = 'point', inherit.aes = F) +
  coord_sf(label_axes = "ENEN") +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering()) +
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5)) 

##precise data ####
SL_attr_precise <- SL_attr |> 
  dplyr::filter(DOP <= 5.2)
dim(SL_attr_precise)
ggplot() + 
  geom_sf(data = st_as_sf(SL_attr_precise), 
          aes(pch = Animal, color = -DOP), alpha = 0.5, 
          show.legend = 'point', inherit.aes = F) +
  coord_sf(label_axes = "ENEN") +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering()) +
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5)) 
st_write(SL_attr_precise, "SL_precise_5.2.shp")

library(tiff)
#Home range####
##MCP####
points <- as(SL_attr_precise[, "Animal"], "Spatial")
cp95 <- mcp(points, percent = 95)
cp50 <- mcp(points, percent = 50)
base <- readTIFF("C:/Users/user-1/Desktop/SL_map_base.tiff")
base <- as.data.frame(base)

ggplot() + 
  geom_sf(data=base)
geom_sf(data = st_as_sf(SL_attr_precise), aes(col = Animal), 
        alpha = 0.5, show.legend = 'point', inherit.aes = F) +
  geom_sf(data = st_as_sf(cp95), fill = NA) +
  coord_sf(label_axes = "ENEN") +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering()) +
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5))   
cparea95 <- as.data.frame(cp95)
cparea95
hrs <- mcp.area(points, percent = seq(50, 100, by = 5), plot = FALSE)
hrs
st_write(st_as_sf(cp95), "MCP95_SL_2024.shp")

cparea50 <- as.data.frame(cp50)
cparea50

st_write(st_as_sf(cp50), "MCP50_SL_2024.shp")

### Read the TIFF image
base <- raster("C:/Users/user-1/Desktop/SL_map_base.tiff")

### Extract SpatialPolygonsDataFrame
base_sp <- as(base, "SpatialPolygonsDataFrame")

### Plot
ggplot() + 
  geom_sf(data = base_sp) +
  geom_sf(data = st_as_sf(SL_attr_precise), aes(col = Animal), 
          alpha = 0.5, show.legend = 'point', inherit.aes = F) +
  geom_sf(data = st_as_sf(cp95), fill = NA) +
  coord_sf() +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering()) +
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5))

##Kernel Density Estimation####
###href####
kern.href <- kernelUD(points, h = "href", grid = 100, hlim = c(0.75, 1.5))
kern.href[[1]]@h
kern.href[[2]]@h
kern.href[[3]]@h

image(kern.href)

kern.href.ver95 <- getverticeshr(kern.href, 95)
kern.href.ver50 <- getverticeshr(kern.href, 50)

ggplot() + 
  geom_sf(data = st_as_sf(SL_attr_precise), aes(col = Animal), 
          alpha = 0.5, show.legend = 'point', inherit.aes = F) +
  geom_sf(data = st_as_sf(kern.href.ver95), fill = NA) +
  coord_sf(label_axes = "ENEN") +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering()) +
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5)) 

kern.href.area <- kernel.area(kern.href)
kern.href.area

st_write(st_as_sf(kern.href.ver95), "kDE.href95_SL_2024.shp")
st_write(st_as_sf(kern.href.ver50), "kDE.href50_SL_2024.shp")

#vignette("adehabitatHR")

###lscv####
kern.LSCV <- kernelUD(points, h = "LSCV", grid = 100, hlim = c(0.75, 1.5))
kern.LSCV[[1]]@h$h
kern.LSCV[[2]]@h$h
kern.LSCV[[3]]@h$h

plotLSCV(kern.LSCV)
kern.LSCV.ver95 <- getverticeshr(kern.LSCV, 95)
kern.LSCV.ver50 <- getverticeshr(kern.LSCV, 50)
ggplot() + 
  geom_sf(data = st_as_sf(SL_attr_precise), aes(col = factor(Animal)), 
          alpha = 0.5, show.legend = 'point', inherit.aes = F) +
  geom_sf(data = st_as_sf(kern.LSCV.ver95), fill = NA) +
  coord_sf(label_axes = "ENEN") +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering()) +
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5)) 

kern.LSCV.area <- kernel.area(kern.LSCV)
kern.LSCV.area

st_write(st_as_sf(kern.LSCV.ver95), "kern_LSCV95_ver_SL.shp")
st_write(st_as_sf(kern.LSCV.ver50), "kern_LSCV50_ver_SL.shp")


##BBMM####
(lik <- liker(trajet, sig2 = 30, rangesig1 = c(10, 100), plotit = TRUE))
(lik <- liker(trajet, sig2 = 30, rangesig1 = c(0, 10), plotit = TRUE))
bbmm <- kernelbb(trajet, sig1 = 7.9, sig2 = 30, grid = 100, extent = 1)
bbmm[[1]]@h
bbmm[[2]]@h
bbmm[[3]]@h

bbmm.ver95 <- st_as_sf(getverticeshr(bbmm, 95))
st_crs(bbmm.ver95) <- UTMZ45
bbmm.ver50 <- st_as_sf(getverticeshr(bbmm, 50))
st_crs(bbmm.ver50) <- UTMZ45

ggplot() + 
  geom_sf(data = st_as_sf(SL_attr_precise), aes(col = factor(Animal)), 
          alpha = 0.5, show.legend = 'point', inherit.aes = F) +
  geom_sf(data = st_as_sf(bbmm.ver95), fill = NA) +
  coord_sf(label_axes = "ENEN") +
  xlab("Longitude") + ylab("Latitude") +
  annotation_north_arrow(location = "tr", which_north = "true", 
                         pad_x = unit(0.75, "cm"), pad_y = unit(0.75, "cm"), 
                         height = unit(1, "cm"),
                         width = unit(1, "cm"),
                         style = north_arrow_orienteering())+
  annotation_scale(location = "bl", width_hint = 0.5) + 
  theme(axis.text.y.left = element_text(angle = 90, hjust = 0.5), 
        axis.text.y.right = element_text(angle = 90, hjust = 0.5)) 

bbmm.area <- kernel.area(bbmm)
bbmm.area

st_write(bbmm.ver95, "BBMM95_SL_2024.shp")
st_write(bbmm.ver50, "BBMM50_SL_2024.shp")

############################################# end ###############################